import React from "react";
import { Pencil, Trash2, ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const DataTable = ({
  headers,
  data,
  sortConfig,
  striped,
  hoverable,
  sortable,
  onSort,
  onEdit,
  onDelete,
}) => {
  const getSortIcon = (field) => {
    if (sortConfig.key !== field) {
      return <ArrowUpDown className="ml-2 h-4 w-4" />;
    }
    return sortConfig.direction === "asc" ? (
      <ArrowUp className="ml-2 h-4 w-4" />
    ) : (
      <ArrowDown className="ml-2 h-4 w-4" />
    );
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            {headers
              .filter((data) => data.view)
              .map((header, index) => (
                <TableHead
                  key={header.field}
                  className={`${
                    sortable ? "cursor-pointer select-none" : ""
                  } ${index === 0 ? "w-16" : "min-w-32"}`}
                  onClick={() => sortable && onSort(header.field)}
                >
                  <div className="flex items-center">
                    <span className="font-semibold">
                      {header.label.toUpperCase()}
                    </span>
                    {sortable && getSortIcon(header.field)}
                  </div>
                </TableHead>
              ))}
            <TableHead className="w-24">
              <span className="font-semibold">ACTIONS</span>
            </TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((row, index) => (
            <TableRow
              key={row.id || index}
              className={`${hoverable ? "hover:bg-muted/50" : ""} ${
                striped && index % 2 === 0 ? "bg-muted/25" : ""
              }`}
            >
              {headers
                .filter((data) => data.view)
                .map((header) => (
                  <TableCell
                    key={header.field}
                    className={`${
                      header.label === "S.No" ? "font-medium" : ""
                    }`}
                  >
                    {header.label === "S.No" ? (
                      <Badge variant="secondary" className="w-8 h-8 rounded-full p-0 flex items-center justify-center">
                        {index + 1}
                      </Badge>
                    ) : header.render ? (
                      header.render(row[header.field], row)
                    ) : (
                      <div
                        className="break-words"
                        title={row[header.field]}
                      >
                        {row[header.field]}
                      </div>
                    )}
                  </TableCell>
                ))}
              <TableCell>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => onEdit(row.Sno, row)}
                    title="Edit"
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="destructive"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => onDelete(row.Sno, row)}
                    title="Delete"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default DataTable;
