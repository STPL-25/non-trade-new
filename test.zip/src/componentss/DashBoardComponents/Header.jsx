// import React from "react";
// import { ChevronDown, Menu, Search, Bell, X } from "lucide-react";
// import { useContext } from "react";
// import { ParentContext } from "../../ParentContext/ParentContext";
// const Header = () => {
//   const {sidebarOpen,setSidebarOpen,toggleCollapse, isCollapsed, setIsCollapsed, } = useContext(ParentContext);
//   return (
//     <header className="bg-white shadow-sm border-b px-4 lg:px-8 py-4">
//       <div className="flex items-center justify-between">
//         <div className="lg:hidden flex items-center space-x-2">
//           {!sidebarOpen && (
//             <button
//               onClick={() => setSidebarOpen(true)}
//               className="p-1.5 rounded-lg hover:bg-slate-700/50 text-slate-400 hover:text-white transition-all duration-200"
//             >
//               <Menu className="w-4 h-4" />
//             </button>
//           )}
//           {sidebarOpen && (
//             <button
//               onClick={() => setSidebarOpen(false)}
//               className="p-1.5 rounded-lg hover:bg-slate-700/50 text-slate-400 hover:text-white transition-all duration-200"
//             >
//               <X className="w-4 h-4" />
//             </button>
//           )}
//         </div>

//       <div className="flex items-center space-x-4">
//           <button className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg"></button>
//           <div className="flex items-center space-x-3">
//             <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-medium">
//               S
//             </div>
//             <div className="hidden md:block">
//               <div className="text-sm font-medium text-gray-900">User</div>
//               <div className="text-xs text-gray-500">User Role</div>
//             </div>
//           </div>
//         </div> 
//       </div>
//     </header>
//   );
// };

// export default Header;
import React from "react";
import { ChevronDown, Menu, Search, Bell, X } from "lucide-react";
import { useContext } from "react";
import { ParentContext } from "../../ParentContext/ParentContext";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

const Header = () => {
  const {
    sidebarOpen,
    setSidebarOpen,
    toggleCollapse,
    isCollapsed,
    setIsCollapsed,
  } = useContext(ParentContext);

  return (
    <header className="bg-background shadow-sm border-b px-4 lg:px-8 py-4">
      <div className="flex items-center justify-between">
        <div className="lg:hidden flex items-center space-x-2">
          {!sidebarOpen && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(true)}
              className="p-1.5 text-muted-foreground hover:text-foreground"
            >
              <Menu className="w-4 h-4" />
            </Button>
          )}
          {sidebarOpen && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(false)}
              className="p-1.5 text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>

        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            className="relative p-2 text-muted-foreground hover:text-foreground"
          >
            <Bell className="w-4 h-4" />
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 h-2 w-2 p-0"
            />
          </Button>
          
        
        </div>
      </div>
    </header>
  );
};

export default Header;