// import React, { useState } from 'react';
// import { 
//   Card, 
//   CardContent, 
//   CardDescription, 
//   CardHeader, 
//   CardTitle 
// } from '@/components/ui/card';
// import { 
//   Button 
// } from '@/components/ui/button';
// import { 
//   Badge 
// } from '@/components/ui/badge';
// import { 
//   Alert, 
//   AlertDescription 
// } from '@/components/ui/alert';
// import { 
//   Textarea 
// } from '@/components/ui/textarea';
// import { 
//   Label 
// } from '@/components/ui/label';
// import { 
//   Separator 
// } from '@/components/ui/separator';
// import { 
//   CheckCircle, 
//   XCircle, 
//   Clock, 
//   User, 
//   Calendar, 
//   DollarSign, 
//   Package,
//   FileText,
//   AlertCircle
// } from 'lucide-react';

// const PurchaseReqHeadApproval = () => {
//   const [selectedRequisition, setSelectedRequisition] = useState(null);
//   const [comments, setComments] = useState('');
//   const [requisitions, setRequisitions] = useState([
//     {
//       id: 'PR-2024-001',
//       requestor: 'John Smith',
//       department: 'IT Department',
//       dateRequested: '2024-08-01',
//       totalAmount: 15750.00,
//       priority: 'High',
//       status: 'Pending',
//       items: [
//         { description: 'Dell Laptop - Core i7', quantity: 5, unitPrice: 1200.00, total: 6000.00 },
//         { description: 'Office Chairs - Ergonomic', quantity: 10, unitPrice: 250.00, total: 2500.00 },
//         { description: 'Network Switch - 24 Port', quantity: 2, unitPrice: 850.00, total: 1700.00 },
//         { description: 'Software Licenses - MS Office', quantity: 15, unitPrice: 150.00, total: 2250.00 },
//         { description: 'External Hard Drives - 2TB', quantity: 8, unitPrice: 125.00, total: 1000.00 },
//         { description: 'Wireless Mouse & Keyboard Sets', quantity: 5, unitPrice: 60.00, total: 300.00 },
//         { description: 'Monitor Stands - Adjustable', quantity: 5, unitPrice: 75.00, total: 375.00 },
//         { description: 'Cable Management Solutions', quantity: 20, unitPrice: 25.00, total: 500.00 },
//         { description: 'Surge Protectors', quantity: 10, unitPrice: 45.00, total: 450.00 },
//         { description: 'Desk Organizers', quantity: 15, unitPrice: 35.00, total: 525.00 },
//         { description: 'Webcams - HD Quality', quantity: 5, unitPrice: 85.00, total: 425.00 },
//         { description: 'Headsets - Noise Cancelling', quantity: 8, unitPrice: 95.00, total: 760.00 },
//         { description: 'Printer Paper - A4 Reams', quantity: 50, unitPrice: 8.00, total: 400.00 },
//         { description: 'Toner Cartridges', quantity: 6, unitPrice: 120.00, total: 720.00 },
//         { description: 'USB Flash Drives - 32GB', quantity: 20, unitPrice: 15.00, total: 300.00 },
//         { description: 'HDMI Cables - 6ft', quantity: 10, unitPrice: 18.00, total: 180.00 },
//         { description: 'Power Banks - 10000mAh', quantity: 8, unitPrice: 35.00, total: 280.00 },
//         { description: 'Desk Lamps - LED', quantity: 12, unitPrice: 45.00, total: 540.00 },
//         { description: 'File Cabinets - 4 Drawer', quantity: 3, unitPrice: 180.00, total: 540.00 }
//       ],
//       justification: 'These items are essential for the new IT team expansion and office setup. The laptops and software licenses are needed for 5 new employees joining next month.',
//       budgetCode: 'IT-2024-Q3',
//       vendor: 'TechCorp Solutions Ltd.'
//     },
//     {
//       id: 'PR-2024-002',
//       requestor: 'Sarah Johnson',
//       department: 'Marketing',
//       dateRequested: '2024-08-02',
//       totalAmount: 8900.00,
//       priority: 'Medium',
//       status: 'Pending',
//       items: [
//         { description: 'Professional Camera - DSLR', quantity: 1, unitPrice: 2500.00, total: 2500.00 },
//         { description: 'Video Equipment Set', quantity: 1, unitPrice: 3200.00, total: 3200.00 },
//         { description: 'Lighting Kit - Studio', quantity: 1, unitPrice: 800.00, total: 800.00 },
//         { description: 'Tripods - Professional', quantity: 3, unitPrice: 150.00, total: 450.00 },
//         { description: 'Memory Cards - 128GB', quantity: 5, unitPrice: 80.00, total: 400.00 },
//         { description: 'Camera Bags', quantity: 2, unitPrice: 120.00, total: 240.00 },
//         { description: 'Backdrop Stand Kit', quantity: 1, unitPrice: 180.00, total: 180.00 },
//         { description: 'Reflectors Set', quantity: 1, unitPrice: 65.00, total: 65.00 },
//         { description: 'External Microphone', quantity: 2, unitPrice: 180.00, total: 360.00 },
//         { description: 'Battery Grips', quantity: 2, unitPrice: 85.00, total: 170.00 },
//         { description: 'Lens Filters Set', quantity: 1, unitPrice: 120.00, total: 120.00 },
//         { description: 'Photo Editing Software', quantity: 3, unitPrice: 200.00, total: 600.00 },
//         { description: 'Portable Hard Drive - 4TB', quantity: 2, unitPrice: 180.00, total: 360.00 },
//         { description: 'Color Calibration Tool', quantity: 1, unitPrice: 250.00, total: 250.00 },
//         { description: 'Camera Cleaning Kits', quantity: 3, unitPrice: 35.00, total: 105.00 },
//         { description: 'Extra Batteries', quantity: 6, unitPrice: 45.00, total: 270.00 },
//         { description: 'Lens Caps & Covers', quantity: 10, unitPrice: 12.00, total: 120.00 },
//         { description: 'Camera Straps - Professional', quantity: 3, unitPrice: 25.00, total: 75.00 },
//         { description: 'Remote Shutter Release', quantity: 2, unitPrice: 30.00, total: 60.00 },
//         { description: 'Equipment Storage Case', quantity: 1, unitPrice: 180.00, total: 180.00 }
//       ],
//       justification: 'Required for upcoming product photography and marketing campaigns. Current equipment is outdated and affecting content quality.',
//       budgetCode: 'MKT-2024-Q3',
//       vendor: 'Creative Media Supplies'
//     },
//     {
//       id: 'PR-2024-003',
//       requestor: 'Mike Wilson',
//       department: 'Operations',
//       dateRequested: '2024-08-03',
//       totalAmount: 12400.00,
//       priority: 'Low',
//       status: 'Pending',
//       items: [
//         { description: 'Industrial Printer - Heavy Duty', quantity: 1, unitPrice: 4500.00, total: 4500.00 },
//         { description: 'Paper Shredder - Commercial', quantity: 1, unitPrice: 800.00, total: 800.00 },
//         { description: 'Laminating Machine - A3', quantity: 1, unitPrice: 650.00, total: 650.00 },
//         { description: 'Binding Machine - Spiral', quantity: 1, unitPrice: 320.00, total: 320.00 },
//         { description: 'Label Printer - Thermal', quantity: 2, unitPrice: 280.00, total: 560.00 },
//         { description: 'Scanner - Document Feeder', quantity: 1, unitPrice: 1200.00, total: 1200.00 },
//         { description: 'Whiteboard - Magnetic Large', quantity: 4, unitPrice: 180.00, total: 720.00 },
//         { description: 'Presentation Remote', quantity: 3, unitPrice: 45.00, total: 135.00 },
//         { description: 'Projector Screen - Portable', quantity: 2, unitPrice: 250.00, total: 500.00 },
//         { description: 'Storage Shelving Units', quantity: 6, unitPrice: 150.00, total: 900.00 },
//         { description: 'Office Supplies Organizers', quantity: 20, unitPrice: 25.00, total: 500.00 },
//         { description: 'Staplers - Heavy Duty', quantity: 8, unitPrice: 35.00, total: 280.00 },
//         { description: 'Hole Punchers - 3-Hole', quantity: 10, unitPrice: 22.00, total: 220.00 },
//         { description: 'Paper Trimmers - Rotary', quantity: 3, unitPrice: 85.00, total: 255.00 },
//         { description: 'Binders - Ring Binders', quantity: 100, unitPrice: 8.00, total: 800.00 },
//         { description: 'Folders - Manila', quantity: 500, unitPrice: 1.20, total: 600.00 },
//         { description: 'Pens - Ballpoint', quantity: 200, unitPrice: 1.50, total: 300.00 },
//         { description: 'Highlighters Set', quantity: 50, unitPrice: 3.00, total: 150.00 },
//         { description: 'Sticky Notes - Assorted', quantity: 100, unitPrice: 2.50, total: 250.00 },
//         { description: 'Rubber Stamps Set', quantity: 1, unitPrice: 180.00, total: 180.00 },
//         { description: 'Date Stamps', quantity: 5, unitPrice: 25.00, total: 125.00 },
//         { description: 'Calculator - Desktop', quantity: 8, unitPrice: 35.00, total: 280.00 },
//         { description: 'Desk Calendars', quantity: 25, unitPrice: 12.00, total: 300.00 },
//         { description: 'Wall Clocks - Digital', quantity: 4, unitPrice: 45.00, total: 180.00 },
//         { description: 'First Aid Kit - Office', quantity: 3, unitPrice: 65.00, total: 195.00 }
//       ],
//       justification: 'Office equipment replacement and upgrade for better operational efficiency. Some items are for the new branch office setup.',
//       budgetCode: 'OPS-2024-Q3',
//       vendor: 'Office Solutions Inc.'
//     }
//   ]);

//   const handleApprove = (id) => {
//     setRequisitions(prev => 
//       prev.map(req => 
//         req.id === id 
//           ? { ...req, status: 'Approved', hodComments: comments }
//           : req
//       )
//     );
//     setComments('');
//     setSelectedRequisition(null);
//   };

//   const handleReject = (id) => {
//     setRequisitions(prev => 
//       prev.map(req => 
//         req.id === id 
//           ? { ...req, status: 'Rejected', hodComments: comments }
//           : req
//       )
//     );
//     setComments('');
//     setSelectedRequisition(null);
//   };

//   const getPriorityColor = (priority) => {
//     switch (priority) {
//       case 'High': return 'bg-red-100 text-red-800 border-red-200';
//       case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
//       case 'Low': return 'bg-green-100 text-green-800 border-green-200';
//       default: return 'bg-gray-100 text-gray-800 border-gray-200';
//     }
//   };

//   const getStatusIcon = (status) => {
//     switch (status) {
//       case 'Approved': return <CheckCircle className="h-4 w-4 text-green-600" />;
//       case 'Rejected': return <XCircle className="h-4 w-4 text-red-600" />;
//       case 'Pending': return <Clock className="h-4 w-4 text-yellow-600" />;
//       default: return <Clock className="h-4 w-4 text-gray-600" />;
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gray-50 p-6">
//       <div className="max-w-full mx-auto">
//         <div className="mb-8">
//           <h1 className="text-3xl font-bold text-gray-900">Purchase Requisition Approval</h1>
//           <p className="text-gray-600 mt-2">Review and approve purchase requisitions from your department</p>
//         </div>

//         <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
//           {/* Requisitions List */}
//           <div className="lg:col-span-1">
//             <Card>
//               <CardHeader>
//                 <CardTitle className="flex items-center gap-2">
//                   <FileText className="h-5 w-5" />
//                   Pending Approvals
//                 </CardTitle>
//                 <CardDescription>
//                   {requisitions.filter(r => r.status === 'Pending').length} requisitions awaiting approval
//                 </CardDescription>
//               </CardHeader>
//               <CardContent className="space-y-4">
//                 {requisitions.map((req) => (
//                   <Card 
//                     key={req.id} 
//                     className={`cursor-pointer transition-all hover:shadow-md ${
//                       selectedRequisition?.id === req.id ? 'ring-2 ring-blue-500' : ''
//                     }`}
//                     onClick={() => setSelectedRequisition(req)}
//                   >
//                     <CardContent className="p-4">
//                       <div className="flex items-center justify-between mb-2">
//                         <span className="font-semibold text-sm">{req.id}</span>
//                         <div className="flex items-center gap-1">
//                           {getStatusIcon(req.status)}
//                           <Badge className={getPriorityColor(req.priority)}>
//                             {req.priority}
//                           </Badge>
//                         </div>
//                       </div>
//                       <div className="space-y-1 text-sm">
//                         <div className="flex items-center gap-2">
//                           <User className="h-4 w-4 text-gray-500" />
//                           <span>{req.requestor}</span>
//                         </div>
//                         <div className="flex items-center gap-2">
//                           <DollarSign className="h-4 w-4 text-gray-500" />
//                           <span className="font-semibold">${req.totalAmount.toLocaleString()}</span>
//                         </div>
//                         <div className="flex items-center gap-2">
//                           <Calendar className="h-4 w-4 text-gray-500" />
//                           <span>{req.dateRequested}</span>
//                         </div>
//                       </div>
//                     </CardContent>
//                   </Card>
//                 ))}
//               </CardContent>
//             </Card>
//           </div>

//           {/* Requisition Details */}
//           <div className="lg:col-span-2">
//             {selectedRequisition ? (
//               <div className="space-y-6">
//                 {/* Header Information */}
//                 <Card>
//                   <CardHeader>
//                     <div className="flex items-center justify-between">
//                       <div>
//                         <CardTitle className="flex items-center gap-2">
//                           <Package className="h-5 w-5" />
//                           {selectedRequisition.id}
//                         </CardTitle>
//                         <CardDescription>{selectedRequisition.department}</CardDescription>
//                       </div>
//                       <Badge className={getPriorityColor(selectedRequisition.priority)}>
//                         {selectedRequisition.priority} Priority
//                       </Badge>
//                     </div>
//                   </CardHeader>
//                   <CardContent>
//                     <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
//                       <div>
//                         <Label className="text-sm font-medium text-gray-500">Requestor</Label>
//                         <p className="text-sm font-semibold mt-1">{selectedRequisition.requestor}</p>
//                       </div>
//                       <div>
//                         <Label className="text-sm font-medium text-gray-500">Date Requested</Label>
//                         <p className="text-sm font-semibold mt-1">{selectedRequisition.dateRequested}</p>
//                       </div>
//                       <div>
//                         <Label className="text-sm font-medium text-gray-500">Budget Code</Label>
//                         <p className="text-sm font-semibold mt-1">{selectedRequisition.budgetCode}</p>
//                       </div>
//                       <div>
//                         <Label className="text-sm font-medium text-gray-500">Preferred Vendor</Label>
//                         <p className="text-sm font-semibold mt-1">{selectedRequisition.vendor}</p>
//                       </div>
//                     </div>
//                   </CardContent>
//                 </Card>

//                 {/* Justification */}
//                 <Card>
//                   <CardHeader>
//                     <CardTitle>Business Justification</CardTitle>
//                   </CardHeader>
//                   <CardContent>
//                     <p className="text-sm text-gray-700">{selectedRequisition.justification}</p>
//                   </CardContent>
//                 </Card>

//                 {/* Items Table */}
//                 <Card>
//                   <CardHeader>
//                     <CardTitle>Requested Items</CardTitle>
//                     <CardDescription>
//                       {selectedRequisition.items.length} items • Total: ${selectedRequisition.totalAmount.toLocaleString()}
//                     </CardDescription>
//                   </CardHeader>
//                   <CardContent>
//                     <div className="overflow-x-auto">
//                       <table className="w-full text-sm">
//                         <thead>
//                           <tr className="border-b">
//                             <th className="text-left p-2 font-medium">Description</th>
//                             <th className="text-right p-2 font-medium">Qty</th>
//                             <th className="text-right p-2 font-medium">Unit Price</th>
//                             <th className="text-right p-2 font-medium">Total</th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {selectedRequisition.items.map((item, index) => (
//                             <tr key={index} className="border-b hover:bg-gray-50">
//                               <td className="p-2">{item.description}</td>
//                               <td className="p-2 text-right">{item.quantity}</td>
//                               <td className="p-2 text-right">${item.unitPrice.toFixed(2)}</td>
//                               <td className="p-2 text-right font-semibold">${item.total.toFixed(2)}</td>
//                             </tr>
//                           ))}
//                         </tbody>
//                         <tfoot>
//                           <tr className="border-t-2 font-semibold bg-gray-50">
//                             <td className="p-2" colSpan="3">Total Amount</td>
//                             <td className="p-2 text-right text-lg">${selectedRequisition.totalAmount.toLocaleString()}</td>
//                           </tr>
//                         </tfoot>
//                       </table>
//                     </div>
//                   </CardContent>
//                 </Card>

//                 {/* Approval Actions */}
//                 {selectedRequisition.status === 'Pending' && (
//                   <Card>
//                     <CardHeader>
//                       <CardTitle>HOD Decision</CardTitle>
//                     </CardHeader>
//                     <CardContent className="space-y-4">
//                       <div>
//                         <Label htmlFor="comments">Comments (Optional)</Label>
//                         <Textarea
//                           id="comments"
//                           placeholder="Add any comments or conditions for approval..."
//                           value={comments}
//                           onChange={(e) => setComments(e.target.value)}
//                           className="mt-2"
//                           rows={3}
//                         />
//                       </div>
//                       <div className="flex gap-3">
//                         <Button
//                           onClick={() => handleApprove(selectedRequisition.id)}
//                           className="flex-1 bg-green-600 hover:bg-green-700"
//                         >
//                           <CheckCircle className="h-4 w-4 mr-2" />
//                           Approve Requisition
//                         </Button>
//                         <Button
//                           onClick={() => handleReject(selectedRequisition.id)}
//                           variant="destructive"
//                           className="flex-1"
//                         >
//                           <XCircle className="h-4 w-4 mr-2" />
//                           Reject Requisition
//                         </Button>
//                       </div>
//                     </CardContent>
//                   </Card>
//                 )}

//                 {/* Status Alert */}
//                 {selectedRequisition.status !== 'Pending' && (
//                   <Alert className={`${selectedRequisition.status === 'Approved' ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>
//                     <AlertCircle className="h-4 w-4" />
//                     <AlertDescription>
//                       <strong>Status:</strong> This requisition has been {selectedRequisition.status.toLowerCase()}.
//                       {selectedRequisition.hodComments && (
//                         <>
//                           <br />
//                           <strong>Comments:</strong> {selectedRequisition.hodComments}
//                         </>
//                       )}
//                     </AlertDescription>
//                   </Alert>
//                 )}
//               </div>
//             ) : (
//               <Card className="h-96 flex items-center justify-center">
//                 <CardContent className="text-center">
//                   <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
//                   <p className="text-gray-500">Select a requisition to view details</p>
//                 </CardContent>
//               </Card>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default PurchaseReqHeadApproval;


import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  CheckCircle, 
  XCircle, 
  Clock, 
  User, 
  Calendar, 
  DollarSign,
  Search,
  Building2,
  Package,
  FileText,
  AlertTriangle,
  ChevronRight,
  Check,
  X
} from 'lucide-react';

const PurchaseApprovalSystem = () => {
  const [selectedReq, setSelectedReq] = useState(null);
  const [comments, setComments] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [pendingAction, setPendingAction] = useState(null);
  
  const [requisitions, setRequisitions] = useState([
    {
      id: 'PR-2024-001',
      requestor: 'John Smith',
      department: 'IT Department',
      dateRequested: '2024-08-01',
      totalAmount: 15750.00,
      priority: 'High',
      status: 'Pending',
      items: [
        { description: 'Dell Laptop - Core i7', quantity: 5, unitPrice: 1200.00, total: 6000.00 },
        { description: 'Office Chairs - Ergonomic', quantity: 10, unitPrice: 250.00, total: 2500.00 },
        { description: 'Network Switch - 24 Port', quantity: 2, unitPrice: 850.00, total: 1700.00 },
        { description: 'Software Licenses - MS Office', quantity: 15, unitPrice: 150.00, total: 2250.00 },
        { description: 'External Hard Drives - 2TB', quantity: 8, unitPrice: 125.00, total: 1000.00 },
        { description: 'Wireless Mouse & Keyboard Set', quantity: 20, unitPrice: 65.00, total: 1300.00 }
      ],
      justification: 'Essential equipment for new IT team expansion. Required for 25 new employees joining the IT department in Q3.',
      budgetCode: 'IT-2024-Q3',
      vendor: 'TechCorp Solutions Ltd.',
      daysWaiting: 3
    },
    {
      id: 'PR-2024-002',
      requestor: 'Sarah Johnson',
      department: 'Marketing',
      dateRequested: '2024-08-02',
      totalAmount: 8900.00,
      priority: 'Medium',
      status: 'Pending',
      items: [
        { description: 'Professional Camera - DSLR', quantity: 1, unitPrice: 2500.00, total: 2500.00 },
        { description: 'Video Equipment Set', quantity: 1, unitPrice: 3200.00, total: 3200.00 },
        { description: 'Lighting Kit - Studio', quantity: 1, unitPrice: 800.00, total: 800.00 },
        { description: 'Tripod - Professional', quantity: 2, unitPrice: 300.00, total: 600.00 },
        { description: 'Memory Cards & Accessories', quantity: 1, unitPrice: 1800.00, total: 1800.00 }
      ],
      justification: 'Required for upcoming product photography and marketing campaigns to enhance brand visibility.',
      budgetCode: 'MKT-2024-Q3',
      vendor: 'Creative Media Supplies',
      daysWaiting: 2
    },
    {
      id: 'PR-2024-003',
      requestor: 'Mike Wilson',
      department: 'Operations',
      dateRequested: '2024-08-03',
      totalAmount: 12400.00,
      priority: 'Low',
      status: 'Approved',
      items: [
        { description: 'Industrial Printer - Heavy Duty', quantity: 1, unitPrice: 4500.00, total: 4500.00 },
        { description: 'Paper Shredder - Commercial', quantity: 1, unitPrice: 800.00, total: 800.00 },
        { description: 'Filing Cabinets - 4 Drawer', quantity: 6, unitPrice: 350.00, total: 2100.00 },
        { description: 'Office Furniture Set', quantity: 1, unitPrice: 5100.00, total: 5100.00 }
      ],
      justification: 'Office equipment replacement for better operational efficiency and workspace organization.',
      budgetCode: 'OPS-2024-Q3',
      vendor: 'Office Solutions Inc.',
      hodComments: 'Approved for operational efficiency.',
      approvalDate: '2024-08-04'
    },
    {
      id: 'PR-2024-004',
      requestor: 'Emily Chen',
      department: 'HR',
      dateRequested: '2024-08-04',
      totalAmount: 5600.00,
      priority: 'Medium',
      status: 'Pending',
      items: [
        { description: 'Training Materials - Leadership', quantity: 50, unitPrice: 45.00, total: 2250.00 },
        { description: 'Projector - HD', quantity: 1, unitPrice: 1200.00, total: 1200.00 },
        { description: 'Training Equipment Set', quantity: 1, unitPrice: 2150.00, total: 2150.00 }
      ],
      justification: 'Required for upcoming leadership training programs and new employee orientation sessions.',
      budgetCode: 'HR-2024-Q3',
      vendor: 'Training Resources Inc.',
      daysWaiting: 1
    },
    {
      id: 'PR-2024-005',
      requestor: 'David Rodriguez',
      department: 'Finance',
      dateRequested: '2024-08-05',
      totalAmount: 3200.00,
      priority: 'High',
      status: 'Rejected',
      items: [
        { description: 'Financial Software License', quantity: 1, unitPrice: 2500.00, total: 2500.00 },
        { description: 'Hardware & Accessories', quantity: 1, unitPrice: 700.00, total: 700.00 }
      ],
      justification: 'Software upgrade for financial reporting and analysis. Current system lacks required compliance features.',
      budgetCode: 'FIN-2024-Q3',
      vendor: 'FinanceTech Solutions',
      hodComments: 'Rejected due to budget constraints. Please resubmit next quarter.',
      approvalDate: '2024-08-06'
    }
  ]);

  const handleAction = (action) => {
    setPendingAction(action);
    setShowConfirmDialog(true);
  };

  const confirmAction = () => {
    if (!selectedReq || !pendingAction) return;

    setRequisitions(prev => 
      prev.map(req => 
        req.id === selectedReq.id 
          ? { 
              ...req, 
              status: pendingAction === 'approve' ? 'Approved' : 'Rejected',
              hodComments: comments || (pendingAction === 'approve' ? 'Approved by HOD' : 'Rejected by HOD'),
              approvalDate: new Date().toISOString().split('T')[0]
            }
          : req
      )
    );
    
    setComments('');
    setShowConfirmDialog(false);
    setPendingAction(null);
    setSelectedReq(null);
  };

  const getPriorityColor = (priority) => {
    const colors = {
      'High': 'bg-red-100 text-red-800 border-red-200',
      'Medium': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'Low': 'bg-green-100 text-green-800 border-green-200'
    };
    return colors[priority] || colors['Medium'];
  };

  const getStatusColor = (status) => {
    const colors = {
      'Approved': 'bg-emerald-50 text-emerald-700 border-emerald-200',
      'Rejected': 'bg-red-50 text-red-700 border-red-200',
      'Pending': 'bg-blue-50 text-blue-700 border-blue-200'
    };
    return colors[status] || colors['Pending'];
  };

  const getStatusIcon = (status) => {
    const icons = {
      'Approved': <CheckCircle className="h-4 w-4" />,
      'Rejected': <XCircle className="h-4 w-4" />,
      'Pending': <Clock className="h-4 w-4" />
    };
    return icons[status] || icons['Pending'];
  };

  const filteredReqs = requisitions.filter(req => 
    req.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.requestor.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const pendingCount = requisitions.filter(r => r.status === 'Pending').length;
  const totalPendingValue = requisitions
    .filter(r => r.status === 'Pending')
    .reduce((sum, r) => sum + r.totalAmount, 0);

  return (
    <div className="min-h-screen w-full bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
            <div>
                <h1 className="text-2xl font-bold text-gray-900">Purchase Approvals</h1>
            </div>
            </div>
            
           
          </div>
        </div>
      </div>

      <div className="max-w-full mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Sidebar */}
          <div className="space-y-6">
            {/* Search */}
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-3 text-gray-400" />
              <Input
                placeholder="Search requisitions..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Requisition List */}
            <div className="space-y-3">
              {filteredReqs.map((req) => (
                <Card 
                  key={req.id}
                  className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                    selectedReq?.id === req.id 
                      ? 'ring-2 ring-blue-500 shadow-md' 
                      : 'hover:shadow-sm'
                  }`}
                  onClick={() => setSelectedReq(req)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <Badge className={`text-xs ${getPriorityColor(req.priority)}`}>
                        {req.priority}
                      </Badge>
                      <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${getStatusColor(req.status)}`}>
                        {getStatusIcon(req.status)}
                        {req.status}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="font-semibold text-gray-900">{req.id}</div>
                      <div className="text-sm text-gray-600">
                        <div>{req.requestor}</div>
                        <div>{req.department}</div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-blue-600">
                          ${req.totalAmount.toLocaleString()}
                        </span>
                        <span className="text-xs text-gray-500">{req.dateRequested}</span>
                      </div>
                      {req.status === 'Pending' && req.daysWaiting > 0 && (
                        <div className="flex items-center gap-1 text-xs text-amber-600">
                          <AlertTriangle className="h-3 w-3" />
                          Waiting {req.daysWaiting} days
                        </div>
                      )}
                    </div>

                    {selectedReq?.id === req.id && (
                      <ChevronRight className="h-4 w-4 text-blue-500 ml-auto" />
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {selectedReq ? (
              <div className="space-y-6">
                {/* Header Card */}
                <Card>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-xl text-gray-900 mb-2">
                          {selectedReq.id}
                        </CardTitle>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <User className="h-4 w-4" />
                            {selectedReq.requestor}
                          </div>
                          <div className="flex items-center gap-1">
                            <Building2 className="h-4 w-4" />
                            {selectedReq.department}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {selectedReq.dateRequested}
                          </div>
                        </div>
                      </div>
                          <div>
                          <div className="text-sm text-gray-600">Items</div>
                          <div className="text-lg font-bold">{selectedReq.items.length}</div>
                        </div>
                      <div className="flex items-center gap-3">
                        <Badge className={getPriorityColor(selectedReq.priority)}>
                          {selectedReq.priority} Priority
                        </Badge>
                        <div className={`flex items-center gap-1 px-3 py-1 rounded-full text-sm ${getStatusColor(selectedReq.status)}`}>
                          {getStatusIcon(selectedReq.status)}
                          {selectedReq.status}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                </Card>

              
             
                {/* Items Table */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Items ({selectedReq.items.length})</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b border-gray-200">
                            <th className="text-left p-3 text-sm font-medium text-gray-700">Description</th>
                            <th className="text-center p-3 text-sm font-medium text-gray-700">Qty</th>
                            <th className="text-right p-3 text-sm font-medium text-gray-700">Uom </th>
                          </tr>
                        </thead>
                        <tbody>
                          {selectedReq.items.map((item, index) => (
                            <tr key={index} className="border-b border-gray-100">
                              <td className="p-3 text-sm">{item.description}</td>
                              <td className="p-3 text-sm text-center">{item.quantity}</td>
                              <td className="p-3 text-sm text-right">Nos</td>
                            </tr>
                          ))}
                        </tbody>
                       
                      </table>
                    </div>
                  </CardContent>
                </Card>

                

                {/* Approval Section */}
                {selectedReq.status === 'Pending' ? (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Approval Decision</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">
                          Comments (Optional)
                        </label>
                        <Textarea
                          placeholder="Add your comments about this approval decision..."
                          value={comments}
                          onChange={(e) => setComments(e.target.value)}
                          rows={3}
                        />
                      </div>
                      
                      <div className="flex gap-4">
                        <Button
                          onClick={() => handleAction('approve')}
                          className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                        >
                          <Check className="h-4 w-4 mr-2" />
                          Approve
                        </Button>
                        <Button
                          onClick={() => handleAction('reject')}
                          variant="destructive"
                          className="flex-1"
                        >
                          <X className="h-4 w-4 mr-2" />
                          Reject
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <Card className={selectedReq.status === 'Approved' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div className={`p-2 rounded-full ${selectedReq.status === 'Approved' ? 'bg-green-100' : 'bg-red-100'}`}>
                          {getStatusIcon(selectedReq.status)}
                        </div>
                        <div>
                          <div className="font-bold text-lg">
                            Requisition {selectedReq.status}
                          </div>
                          {selectedReq.approvalDate && (
                            <div className="text-sm text-gray-600">
                              Decision made on {selectedReq.approvalDate}
                            </div>
                          )}
                        </div>
                      </div>
                      {selectedReq.hodComments && (
                        <div className="bg-white p-4 rounded-lg">
                          <div className="text-sm text-gray-700">
                            <span className="font-medium">HOD Comments:</span> {selectedReq.hodComments}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </div>
            ) : (
              <Card className="h-96 flex items-center justify-center">
                <CardContent className="text-center">
                  <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-medium text-gray-900 mb-2">Select a Requisition</h3>
                  <p className="text-gray-500">Choose a purchase requisition from the list to view details</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {pendingAction === 'approve' ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <XCircle className="h-5 w-5 text-red-600" />
              )}
              Confirm {pendingAction === 'approve' ? 'Approval' : 'Rejection'}
            </DialogTitle>
            <DialogDescription>
              Are you sure you want to {pendingAction} requisition {selectedReq?.id}?
            </DialogDescription>
          </DialogHeader>
          
          {comments && (
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="text-sm">
                <span className="font-medium">Your Comments:</span> {comments}
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              Cancel
            </Button>
            <Button
              onClick={confirmAction}
              className={pendingAction === 'approve' 
                ? 'bg-green-600 hover:bg-green-700' 
                : 'bg-red-600 hover:bg-red-700'
              }
            >
              Confirm {pendingAction === 'approve' ? 'Approval' : 'Rejection'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PurchaseApprovalSystem;