import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
// Table components are implemented inline below
import { Plus, Edit2, Upload, CheckCircle, Clock, AlertCircle, FileText, Users, Building2 } from 'lucide-react';

// Simple Table Components
const Table = ({ children, ...props }) => (
  <div className="w-full overflow-auto">
    <table className="w-full caption-bottom text-sm" {...props}>
      {children}
    </table>
  </div>
);

const TableHeader = ({ children, ...props }) => (
  <thead className="[&_tr]:border-b bg-gray-50" {...props}>
    {children}
  </thead>
);

const TableBody = ({ children, ...props }) => (
  <tbody className="[&_tr:last-child]:border-0" {...props}>
    {children}
  </tbody>
);

const TableRow = ({ children, ...props }) => (
  <tr className="border-b transition-colors hover:bg-gray-50" {...props}>
    {children}
  </tr>
);

const TableHead = ({ children, ...props }) => (
  <th className="h-12 px-4 text-left align-middle font-medium text-gray-500 [&:has([role=checkbox])]:pr-0" {...props}>
    {children}
  </th>
);

const TableCell = ({ children, ...props }) => (
  <td className="p-4 align-middle [&:has([role=checkbox])]:pr-0" {...props}>
    {children}
  </td>
);

const PurchaseRequisitionSystem = () => {
  const [currentView, setCurrentView] = useState('user');
  const [requisitions, setRequisitions] = useState([]);
  const [currentRequisition, setCurrentRequisition] = useState(null);
  const [userFormData, setUserFormData] = useState({
    company: '',
    division: '',
    branch: '',
    requiredDate: '',
    items: [],
    suggestedSuppliers: []
  });

  // Sample data
  const companies = ['Tech Corp', 'Manufacturing Ltd', 'Services Inc'];
  const divisions = ['IT', 'Operations', 'Finance', 'HR'];
  const branches = ['Mumbai', 'Delhi', 'Bangalore', 'Chennai'];
  const sampleSuppliers = ['Supplier A', 'Supplier B', 'Supplier C', 'Supplier D'];

  // User Requisition Form Component
  const UserRequisitionForm = () => {
    const [newItem, setNewItem] = useState({
      name: '',
      quantity: '',
      specification: '',
      estimatedCost: ''
    });

    const addItem = () => {
      if (newItem.name && newItem.quantity) {
        setUserFormData(prev => ({
          ...prev,
          items: [...prev.items, { ...newItem, id: Date.now() }]
        }));
        setNewItem({ name: '', quantity: '', specification: '', estimatedCost: '' });
      }
    };

    const addSupplier = (supplier) => {
      if (!userFormData.suggestedSuppliers.includes(supplier)) {
        setUserFormData(prev => ({
          ...prev,
          suggestedSuppliers: [...prev.suggestedSuppliers, supplier]
        }));
      }
    };

    const submitRequisition = () => {
      if (userFormData.company && userFormData.items.length > 0) {
        const newReq = {
          id: Date.now(),
          ...userFormData,
          status: 'pending',
          submittedDate: new Date().toISOString().split('T')[0],
          purchaseDeptData: {
            editedItems: userFormData.items.map(item => ({
              ...item,
              minQty: '',
              maxQty: '',
              reason: ''
            })),
            selectedSuppliers: [],
            quotations: [],
            finalSupplier: null
          }
        };
        setRequisitions(prev => [...prev, newReq]);
        setUserFormData({
          company: '',
          division: '',
          branch: '',
          requiredDate: '',
          items: [],
          suggestedSuppliers: []
        });
        alert('Requisition submitted successfully!');
      }
    };

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Create Purchase Requisition
            </CardTitle>
            <CardDescription>Fill in the basic information and add items for your requisition</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="company">Company</Label>
                <Select value={userFormData.company} onValueChange={(value) => setUserFormData(prev => ({ ...prev, company: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Company" />
                  </SelectTrigger>
                  <SelectContent>
                    {companies.map(company => (
                      <SelectItem key={company} value={company}>{company}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="division">Division</Label>
                <Select value={userFormData.division} onValueChange={(value) => setUserFormData(prev => ({ ...prev, division: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Division" />
                  </SelectTrigger>
                  <SelectContent>
                    {divisions.map(division => (
                      <SelectItem key={division} value={division}>{division}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="branch">Branch</Label>
                <Select value={userFormData.branch} onValueChange={(value) => setUserFormData(prev => ({ ...prev, branch: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Branch" />
                  </SelectTrigger>
                  <SelectContent>
                    {branches.map(branch => (
                      <SelectItem key={branch} value={branch}>{branch}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="requiredDate">Required Date</Label>
                <Input
                  type="date"
                  value={userFormData.requiredDate}
                  onChange={(e) => setUserFormData(prev => ({ ...prev, requiredDate: e.target.value }))}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Add Items</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label>Item Name</Label>
                <Input
                  value={newItem.name}
                  onChange={(e) => setNewItem(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter item name"
                />
              </div>
              <div>
                <Label>Quantity</Label>
                <Input
                  type="number"
                  value={newItem.quantity}
                  onChange={(e) => setNewItem(prev => ({ ...prev, quantity: e.target.value }))}
                  placeholder="Enter quantity"
                />
              </div>
              <div>
                <Label>Estimated Cost</Label>
                <Input
                  type="number"
                  value={newItem.estimatedCost}
                  onChange={(e) => setNewItem(prev => ({ ...prev, estimatedCost: e.target.value }))}
                  placeholder="Enter cost"
                />
              </div>
              <div className="flex items-end">
                <Button onClick={addItem} className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </div>
            </div>
            <div>
              <Label>Specification</Label>
              <Textarea
                value={newItem.specification}
                onChange={(e) => setNewItem(prev => ({ ...prev, specification: e.target.value }))}
                placeholder="Enter item specifications"
              />
            </div>

            {userFormData.items.length > 0 && (
              <div>
                <Label>Added Items</Label>
                <div className="border rounded-lg p-4 space-y-2 max-h-40 overflow-y-auto">
                  {userFormData.items.map(item => (
                    <div key={item.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                      <div>
                        <span className="font-medium">{item.name}</span>
                        <span className="text-sm text-gray-500 ml-2">Qty: {item.quantity}</span>
                        {item.estimatedCost && <span className="text-sm text-gray-500 ml-2">Cost: ₹{item.estimatedCost}</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Suggest Suppliers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2 mb-4">
              {sampleSuppliers.map(supplier => (
                <Button
                  key={supplier}
                  variant="outline"
                  size="sm"
                  onClick={() => addSupplier(supplier)}
                  disabled={userFormData.suggestedSuppliers.includes(supplier)}
                >
                  {supplier}
                </Button>
              ))}
            </div>
            {userFormData.suggestedSuppliers.length > 0 && (
              <div>
                <Label>Suggested Suppliers</Label>
                <div className="flex flex-wrap gap-2 mt-2">
                  {userFormData.suggestedSuppliers.map(supplier => (
                    <Badge key={supplier} variant="secondary">{supplier}</Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Button onClick={submitRequisition} className="w-full" size="lg">
          Submit Requisition
        </Button>
      </div>
    );
  };

  // Purchase Department Component
  const PurchaseDepartment = () => {
    const [editDialog, setEditDialog] = useState(false);
    const [quotationDialog, setQuotationDialog] = useState(false);
    const [selectedReq, setSelectedReq] = useState(null);
    const [editingItem, setEditingItem] = useState(null);

    const handleEditItem = (reqId, itemId, updates) => {
      setRequisitions(prev => prev.map(req => {
        if (req.id === reqId) {
          return {
            ...req,
            purchaseDeptData: {
              ...req.purchaseDeptData,
              editedItems: req.purchaseDeptData.editedItems.map(item => 
                item.id === itemId ? { ...item, ...updates } : item
              )
            }
          };
        }
        return req;
      }));
    };

    const addSupplierQuotation = (reqId, supplier, quotation) => {
      setRequisitions(prev => prev.map(req => {
        if (req.id === reqId) {
          const updatedSuppliers = req.purchaseDeptData.selectedSuppliers.includes(supplier) 
            ? req.purchaseDeptData.selectedSuppliers 
            : [...req.purchaseDeptData.selectedSuppliers, supplier];
          
          const updatedQuotations = req.purchaseDeptData.quotations.filter(q => q.supplier !== supplier);
          updatedQuotations.push({ supplier, amount: quotation, date: new Date().toISOString().split('T')[0] });

          return {
            ...req,
            purchaseDeptData: {
              ...req.purchaseDeptData,
              selectedSuppliers: updatedSuppliers,
              quotations: updatedQuotations
            }
          };
        }
        return req;
      }));
    };

    const selectFinalSupplier = (reqId, supplier) => {
      setRequisitions(prev => prev.map(req => {
        if (req.id === reqId) {
          return {
            ...req,
            status: 'approved',
            purchaseDeptData: {
              ...req.purchaseDeptData,
              finalSupplier: supplier
            }
          };
        }
        return req;
      }));
    };

    const pendingRequisitions = requisitions.filter(req => req.status === 'pending');

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Purchase Department Dashboard
            </CardTitle>
            <CardDescription>Review and process purchase requisitions</CardDescription>
          </CardHeader>
        </Card>

        {pendingRequisitions.map(req => (
          <Card key={req.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Requisition #{req.id}</CardTitle>
                  <CardDescription>
                    {req.company} - {req.division} - {req.branch} | Required: {req.requiredDate}
                  </CardDescription>
                </div>
                <Badge variant="outline">
                  <Clock className="h-3 w-3 mr-1" />
                  Pending
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium">Items Requested</Label>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Item</TableHead>
                        <TableHead>Qty</TableHead>
                        <TableHead>Min Qty</TableHead>
                        <TableHead>Max Qty</TableHead>
                        <TableHead>Reason</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {req.purchaseDeptData.editedItems.map(item => (
                        <TableRow key={item.id}>
                          <TableCell>{item.name}</TableCell>
                          <TableCell>{item.quantity}</TableCell>
                          <TableCell>{item.minQty || '-'}</TableCell>
                          <TableCell>{item.maxQty || '-'}</TableCell>
                          <TableCell>{item.reason || '-'}</TableCell>
                          <TableCell>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setEditingItem(item);
                                setSelectedReq(req);
                                setEditDialog(true);
                              }}
                            >
                              <Edit2 className="h-3 w-3" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                <div>
                  <Label className="text-sm font-medium">Supplier Management</Label>
                  <div className="flex gap-2 mt-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedReq(req);
                        setQuotationDialog(true);
                      }}
                    >
                      <Upload className="h-4 w-4 mr-2" />
                      Add Quotations
                    </Button>
                    {req.purchaseDeptData.quotations.length >= 2 && (
                      <Button
                        onClick={() => {
                          const lowestQuote = req.purchaseDeptData.quotations.reduce((min, q) => 
                            q.amount < min.amount ? q : min
                          );
                          selectFinalSupplier(req.id, lowestQuote.supplier);
                        }}
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Select Lowest Quote
                      </Button>
                    )}
                  </div>
                  
                  {req.purchaseDeptData.quotations.length > 0 && (
                    <div className="mt-2">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Supplier</TableHead>
                            <TableHead>Quotation Amount</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Action</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {req.purchaseDeptData.quotations.map(quote => (
                            <TableRow key={quote.supplier}>
                              <TableCell>{quote.supplier}</TableCell>
                              <TableCell>₹{quote.amount}</TableCell>
                              <TableCell>{quote.date}</TableCell>
                              <TableCell>
                                <Button
                                  size="sm"
                                  onClick={() => selectFinalSupplier(req.id, quote.supplier)}
                                >
                                  Select
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Edit Item Dialog */}
        <Dialog open={editDialog} onOpenChange={setEditDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Item Quantities</DialogTitle>
              <DialogDescription>
                Set minimum and maximum quantities with reason for changes
              </DialogDescription>
            </DialogHeader>
            {editingItem && (
              <div className="space-y-4">
                <div>
                  <Label>Item: {editingItem.name}</Label>
                  <div className="text-sm text-gray-500">Original Quantity: {editingItem.quantity}</div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Minimum Quantity</Label>
                    <Input
                      type="number"
                      value={editingItem.minQty}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, minQty: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label>Maximum Quantity</Label>
                    <Input
                      type="number"
                      value={editingItem.maxQty}
                      onChange={(e) => setEditingItem(prev => ({ ...prev, maxQty: e.target.value }))}
                    />
                  </div>
                </div>
                <div>
                  <Label>Reason for Change</Label>
                  <Textarea
                    value={editingItem.reason}
                    onChange={(e) => setEditingItem(prev => ({ ...prev, reason: e.target.value }))}
                    placeholder="Enter reason for quantity adjustment"
                  />
                </div>
              </div>
            )}
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditDialog(false)}>Cancel</Button>
              <Button onClick={() => {
                if (selectedReq && editingItem) {
                  handleEditItem(selectedReq.id, editingItem.id, {
                    minQty: editingItem.minQty,
                    maxQty: editingItem.maxQty,
                    reason: editingItem.reason
                  });
                  setEditDialog(false);
                  setEditingItem(null);
                }
              }}>
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Quotation Dialog */}
        <Dialog open={quotationDialog} onOpenChange={setQuotationDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Supplier Quotations</DialogTitle>
              <DialogDescription>
                Add quotations from at least 2 suppliers (minimum requirement)
              </DialogDescription>
            </DialogHeader>
            {selectedReq && (
              <div className="space-y-4">
                {sampleSuppliers.map(supplier => (
                  <div key={supplier} className="flex items-center gap-4">
                    <div className="flex-1">
                      <Label>{supplier}</Label>
                    </div>
                    <div className="flex-1">
                      <Input
                        type="number"
                        placeholder="Enter quotation amount"
                        onBlur={(e) => {
                          if (e.target.value) {
                            addSupplierQuotation(selectedReq.id, supplier, parseFloat(e.target.value));
                          }
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
            <DialogFooter>
              <Button onClick={() => setQuotationDialog(false)}>Done</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    );
  };

  // Approved Requisitions Component
  const ApprovedRequisitions = () => {
    const approvedReqs = requisitions.filter(req => req.status === 'approved');

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5" />
              Approved Requisitions
            </CardTitle>
            <CardDescription>Requisitions ready for next process</CardDescription>
          </CardHeader>
        </Card>

        {approvedReqs.map(req => (
          <Card key={req.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle>Requisition #{req.id}</CardTitle>
                  <CardDescription>
                    {req.company} - {req.division} - {req.branch}
                  </CardDescription>
                </div>
                <Badge variant="default">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Approved
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium">Selected Supplier</Label>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <div className="font-medium">{req.purchaseDeptData.finalSupplier}</div>
                    <div className="text-sm text-gray-600">
                      Amount: ₹{req.purchaseDeptData.quotations.find(q => q.supplier === req.purchaseDeptData.finalSupplier)?.amount}
                    </div>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium">Items</Label>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Item</TableHead>
                        <TableHead>Approved Qty</TableHead>
                        <TableHead>Specification</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {req.items.map(item => (
                        <TableRow key={item.id}>
                          <TableCell>{item.name}</TableCell>
                          <TableCell>{item.quantity}</TableCell>
                          <TableCell>{item.specification}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {approvedReqs.length === 0 && (
          <Card>
            <CardContent className="text-center py-8">
              <AlertCircle className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500">No approved requisitions yet</p>
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Purchase Requisition System</h1>
          <p className="text-gray-600">Manage purchase requisitions from creation to approval</p>
        </div>

        <Tabs value={currentView} onValueChange={setCurrentView} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="user" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Create Requisition
            </TabsTrigger>
            <TabsTrigger value="purchase" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Purchase Dept
              {requisitions.filter(r => r.status === 'pending').length > 0 && (
                <Badge variant="destructive" className="ml-1">
                  {requisitions.filter(r => r.status === 'pending').length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="approved" className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              Approved
            </TabsTrigger>
          </TabsList>

          <TabsContent value="user">
            <UserRequisitionForm />
          </TabsContent>

          <TabsContent value="purchase">
            <PurchaseDepartment />
          </TabsContent>

          <TabsContent value="approved">
            <ApprovedRequisitions />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default PurchaseRequisitionSystem;