import { useState } from "react";
import { Eye, EyeOff, Lock, User, Building, MapPin, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const SignupPage = () => {
  const [formFields, setFormFields] = useState({
    ecnoName: "",
    company: "",
    division: "",
    branch: "",
    department: "",
    password: "",
    confirmPassword: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormFields((prevValue) => ({ ...prevValue, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      // Check if passwords match
      if (formFields.password !== formFields.confirmPassword) {
        alert("Passwords do not match!");
        return;
      }
      console.log("Form submitted:", formFields);
    } catch (error) {
      console.log(error);
    }
  };

  const isFormValid = () => {
    return Object.values(formFields).every(field => field.trim() !== "") && 
           formFields.password === formFields.confirmPassword;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-blue-200 to-blue-300 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg bg-white/95 backdrop-blur-xl border-white/50 shadow-2xl">
        <CardHeader className="space-y-1 pb-6">
          <CardTitle className="text-2xl font-bold text-center text-gray-800">
            Create Account
          </CardTitle>
          {/* <p className="text-sm text-gray-600 text-center">
            Sign up for a new account
          </p> */}
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* ECNO Name Field */}
            <div className="space-y-2">
              <Label htmlFor="ecnoName" className="text-sm font-medium text-gray-700">
                ECNO NAME
              </Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  id="ecno"
                  name="ecno"
                  type="text"
                  value={formFields.ecnoName}
                  onChange={handleChange}
                  placeholder="Enter ECNO"
                  className="pl-10 h-12 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
            </div>

            {/* Company Field */}
            <div className="space-y-2">
              <Label htmlFor="company" className="text-sm font-medium text-gray-700">
                SELECT COMPANY
              </Label>
              <div className="relative">
                
                <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <select
                  id="company"
                  name="company"
                  value={formFields.company}
                  onChange={handleChange}
                  className="w-full pl-10 h-12 border border-gray-300 rounded-md focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 bg-white text-gray-900"
                >
                  <option value="">Select Company</option>
                  <option value="company1">Company 1</option>
                  <option value="company2">Company 2</option>
                  <option value="company3">Company 3</option>
                </select>
              </div>
            </div>

            {/* Division Field */}
            <div className="space-y-2">
              <Label htmlFor="division" className="text-sm font-medium text-gray-700">
                DIVISION
              </Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <select
                  id="division"
                  name="division"
                  value={formFields.division}
                  onChange={handleChange}
                  className="w-full pl-10 h-12 border border-gray-300 rounded-md focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 bg-white text-gray-900"
                >
                  <option value="">Select Division</option>
                  <option value="north">North Division</option>
                  <option value="south">South Division</option>
                  <option value="east">East Division</option>
                  <option value="west">West Division</option>
                </select>
              </div>
            </div>

            {/* Branch Field */}
            <div className="space-y-2">
              <Label htmlFor="branch" className="text-sm font-medium text-gray-700">
                BRANCH
              </Label>
              <div className="relative">
                <Building className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <select
                  id="branch"
                  name="branch"
                  value={formFields.branch}
                  onChange={handleChange}
                  className="w-full pl-10 h-12 border border-gray-300 rounded-md focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 bg-white text-gray-900"
                >
                  <option value="">Select Branch</option>
                  <option value="branch1">Branch 1</option>
                  <option value="branch2">Branch 2</option>
                  <option value="branch3">Branch 3</option>
                </select>
              </div>
            </div>

            {/* Department Field */}
            <div className="space-y-2">
              <Label htmlFor="department" className="text-sm font-medium text-gray-700">
                DEPARTMENT
              </Label>
              <div className="relative">
                <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  id="department"
                  name="department"
                  type="text"
                  value={formFields.department}
                  onChange={handleChange}
                  placeholder="Enter Department"
                  className="pl-10 h-12 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                />
              </div>
            </div>

            {/* Password Field */}
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                PASSWORD
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={formFields.password}
                  onChange={handleChange}
                  placeholder="Enter password"
                  className="pl-10 pr-10 h-12 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>

            {/* Confirm Password Field */}
            <div className="space-y-2">
              <Label htmlFor="confirmPassword" className="text-sm font-medium text-gray-700">
                CONFIRM PASSWORD
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  value={formFields.confirmPassword}
                  onChange={handleChange}
                  placeholder="Confirm password"
                  className="pl-10 h-12 border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showConfirmPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
              {formFields.confirmPassword && formFields.password !== formFields.confirmPassword && (
                <p className="text-sm text-red-600">Passwords do not match</p>
              )}
            </div>

            {/* Sign Up Button */}
            <Button
              type="submit"
              disabled={!isFormValid()}
              className="w-full h-12 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold shadow-lg hover:shadow-xl transform hover:scale-[1.01] transition-all duration-200 mt-8"
            >
              Create Account
            </Button>

            {/* Already have account link */}
            <div className="text-center pt-4">
              <p className="text-sm text-gray-600">
                Already have an account?{" "}
                <Button
                  type="button"
                  variant="link"
                  className="text-sm text-blue-600 hover:text-blue-700 font-semibold p-0 h-auto"
                >
                  Sign In
                </Button>
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default SignupPage;