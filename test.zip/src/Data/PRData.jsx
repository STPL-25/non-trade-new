
// import {
//   CalendarDays,
//   Plus,
//   Save,
//   Send,
//   Building2,
//   Eye,
//   EyeOff,
//   Maximize2,
//   Minimize2,
//   Menu,
//   X,
// } from "lucide-react"; 

// const Companys=[
//   "Garsons Private Limited",
//   "Space Textiles Private Limited"
//  ]
//   const divisions = [
//     "SKTM",
//     "TCS"
//   ];

//   const branches = [
//    "CBE3",
//    "HSR",
//    "KGR",
//    "MTP",
//    "KPM"
//   ];

//   const reasons = [
//     "Equipment Replacement",
//     "New Equipment Purchase",
//     "Office Supplies",
//     "Maintenance & Repair",
//     "Software License",
//     "Professional Services",
//     "Marketing Materials",
//     "Training & Development",
//     "Other",
//   ];
//  const priorities = [
//     { value: "urgent", label: "Urgent", color: "bg-red-100 text-red-800" },
//     { value: "high", label: "High", color: "bg-orange-100 text-orange-800" },
//     {
//       value: "medium",
//       label: "Medium",
//       color: "bg-yellow-100 text-yellow-800",
//     },
//     { value: "low", label: "Low", color: "bg-green-100 text-green-800" },
//   ];

//   const tabs = [
//     { id: "basic", label: "Basic Info", icon: CalendarDays },
//     { id: "items", label: "Items", icon: Plus },
//     { id: "summary", label: "Summary", icon: Eye },
//   ];

// const supplierFields = [
//     {
//       name: "name",
//       label: "Company Name",
//       placeholder: "Company name",
//       required: true,
//       type: "text",
//     },
//     {
//       name: "contactPerson",
//       label: "Contact Person",
//       placeholder: "Contact person",
//       type: "text",
//     },
//     {
//       name: "phone",
//       label: "Phone",
//       placeholder: "Phone number",
//       required: true,
//       type: "text",
//     },
//     {
//       name: "email",
//       label: "Email",
//       placeholder: "Email address",
//       type: "email",
//     },
//     {
//       name: "address",
//       label: "Address",
//       placeholder: "Complete address",
//       required: true,
//       type: "textarea",
//       gridSpan: "sm:col-span-2",
//     },
//   ];
//   const itemFields = [
//     {
//       name: "description",
//       label: "Description",
//       placeholder: "Item description",
//       required: true,
//       gridSpan: "sm:col-span-2",
//       type: "text",
//     },
//     {
//       name: "quantity",
//       label: "Quantity",
//       type: "number",
//       min: 1,
//       placeholder: "",
//       required: true,
//     },
    
//     { name: "uom", label: "UOM", type: "text" },
//     {
//       name: "specifications",
//       label: "Specifications",
//       type: "textarea",
//       gridSpan: "sm:col-span-2",
//     },
  
//   ];
//     const basicInfoFields = [
//           {
//       name: "company",
//       label: "Company",
//       type: "select",
//       required: true,
//       options: Companys, 
//     },
//     {
//       name: "division",
//       label: "Division",
//       type: "select",
//       required: true,
//       options: divisions, 
//     },
//     {
//       name: "branch",
//       label: "Branch",
//       type: "select",
//       required: true,
//       options: branches,
//     },
//     {
//       name: "department",
//       label: "Department",
//       type: "text",
//       placeholder: "Department",
//     },
//     {
//       name: "requestedBy",
//       label: "Requested By",
//       type: "text",
//       required: true,
//       placeholder: "Your Ecno",
//     },
//     {
//       name: "requiredDate",
//       label: "Required Date",
//       type: "date",
//       required: true,
//     },
//     {
//       name: "priority",
//       label: "Priority",
//       type: "select",
//       required: true,
//       options: priorities.map((p) => ({ label: p.label, value: p.value })),
//     },
//     {
//       name: "reason",
//       label: "Reason",
//       type: "select",
//       required: true,
//       options: reasons,
//       gridSpan: "sm:col-span-2",
//     },
//     // {
//     //   name: " ",
//     //   label: "Budget Code",
//     //   type: "text",
//     //   placeholder: "Budget code",
//     //   gridSpan: "sm:col-span-2",
//     // },
//   ];


//   export {itemFields,supplierFields,basicInfoFields,tabs,priorities }



import { useContext } from "react";
import {
  CalendarDays,
  Plus,
  Save,
  Send,
  Building2,
  Eye,
  EyeOff,
  Maximize2,
  Minimize2,
  Menu,
  X,
} from "lucide-react";
import { ParentContext } from "@/ParentContext/ParentContext";
// Assuming you have a context like this - replace with your actual context
// import { DataContext } from './DataContext';

const reasons = [
  "Equipment Replacement",
  "New Equipment Purchase",
  "Office Supplies",
  "Maintenance & Repair",
  "Software License",
  "Professional Services",
  "Marketing Materials",
  "Training & Development",
  "Other",
];

const priorities = [
  { value: "urgent", label: "Urgent", color: "bg-red-100 text-red-800" },
  { value: "high", label: "High", color: "bg-orange-100 text-orange-800" },
  {
    value: "medium",
    label: "Medium",
    color: "bg-yellow-100 text-yellow-800",
  },
  { value: "low", label: "Low", color: "bg-green-100 text-green-800" },
];

const tabs = [
  { id: "basic", label: "Basic Info", icon: CalendarDays },
  { id: "items", label: "Items", icon: Plus },
  { id: "summary", label: "Summary", icon: Eye },
];

const supplierFields = [
  {
    name: "name",
    label: "Company Name",
    placeholder: "Company name",
    required: true,
    type: "text",
  },
  {
    name: "contactPerson",
    label: "Contact Person",
    placeholder: "Contact person",
    type: "text",
  },
  {
    name: "phone",
    label: "Phone",
    placeholder: "Phone number",
    required: true,
    type: "text",
  },
  {
    name: "email",
    label: "Email",
    placeholder: "Email address",
    type: "email",
  },
  {
    name: "address",
    label: "Address",
    placeholder: "Complete address",
    required: true,
    type: "textarea",
    gridSpan: "sm:col-span-2",
  },
];

const itemFields = [
  {
    name: "description",
    label: "Description",
    placeholder: "Item description",
    required: true,
    gridSpan: "sm:col-span-2",
    type: "text",
  },
  {
    name: "quantity",
    label: "Quantity",
    type: "number",
    min: 1,
    placeholder: "",
    required: true,
  },
  { name: "uom", label: "UOM", type: "text" },
  {
    name: "specifications",
    label: "Specifications",
    type: "textarea",
    gridSpan: "sm:col-span-2",
  },
];

// Custom hook to get basic info fields with context data
const useBasicInfoFields = () => {
  // Replace 'DataContext' with your actual context name
  const { companyDetails,divDetails ,branchDetails} = useContext(ParentContext);

  return [
    {
      name: "COMCODE",
      label: "Company",
      type: "select",
      required: true,
      options: companyDetails || [], 
    },
    {
      name: "DIVCODE",
      label: "Division",
      type: "select",
      required: true,
      options: divDetails || [],
    },
    {
      name: "BRN_SNO",
      label: "Branch",
      type: "select",
      required: true,
      options:branchDetails ||[],
    },
    {
      name: "DEPT",
      label: "Department",
      type: "text",
      placeholder: "Department",
    },
    {
      name: "ECNO",
      label: "Requested By",
      type: "text",
      required: true,
      placeholder: "Your Ecno",
    },
    {
      name: "REQ_DATE",
      label: "Required Date",
      type: "date",
      required: true,
    },
    {
      name: "PRIORITY",
      label: "Priority",
      type: "select",
      required: true,
      options: priorities.map((p) => ({ label: p.label, value: p.value })),
    },
    {
      name: "REASON",
      label: "Reason",
      type: "select",
      required: true,
      options: reasons,
      gridSpan: "sm:col-span-2",
    },
  ];
};

export { itemFields, supplierFields, useBasicInfoFields, tabs, priorities };