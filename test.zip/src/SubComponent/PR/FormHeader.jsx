// components/PurchaseRequisition/FormHeader.jsx
import React from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Minimize2, Maximize2, Eye, EyeOff } from "lucide-react";

const FormHeader = ({ 
  isFullscreen, 
  setIsFullscreen, 
  showSummary, 
  setShowSummary, 
  mobileMenuOpen, 
  setMobileMenuOpen,
  tabs,
  activeTab,
  setActiveTab 
}) => {
  return (
    <div className="sticky top-0 z-40 bg-white border-b px-4 py-3">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-gray-900">
          Purchase Requisition
        </h1>
        <div className="flex items-center gap-2">
          {/* Mobile Menu Toggle */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden h-8 w-8 p-0"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </Button>

          {/* Desktop Controls */}
          <div className="hidden md:flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="h-8 px-2"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowSummary(!showSummary)}
              className="h-8 px-2"
            >
              {showSummary ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              <span className="ml-1 hidden lg:inline">Summary</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden mt-3 p-3 bg-gray-50 rounded-lg">
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setIsFullscreen(!isFullscreen);
                setMobileMenuOpen(false);
              }}
              className="h-8 px-3"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4 mr-1" /> : <Maximize2 className="w-4 h-4 mr-1" />}
              {isFullscreen ? "Exit" : "Fullscreen"}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setShowSummary(!showSummary);
                setMobileMenuOpen(false);
              }}
              className="h-8 px-3"
            >
              {showSummary ? <EyeOff className="w-4 h-4 mr-1" /> : <Eye className="w-4 h-4 mr-1" />}
              Summary
            </Button>
          </div>
        </div>
      )}

      {/* Mobile Tab Navigation */}
      <div className="md:hidden mt-3">
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 flex items-center justify-center py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                  activeTab === tab.id
                    ? "bg-white text-blue-700 shadow-sm"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                <Icon className="w-4 h-4 mr-1" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default FormHeader;
