import Dashboard from "./Dashboard/Dashboard";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { ParentProvider } from "./ParentContext/ParentContext";
import { Toaster } from "sonner";

function App(props) {
  const router = createBrowserRouter([
    {
      path: "/",
      element: <LoginPage />,
    },
     {
      path: "/signup",
      element: <SignupPage />,
    },
    {
      path: "/dashboard",
      element: (
        <ParentProvider>
          <Dashboard />
        </ParentProvider>
      ),
    },
  ]);
  return (
    <>
      <Toaster position="top-right" richColors />
      <RouterProvider router={router} />
    </>
  );
}

export default App;
