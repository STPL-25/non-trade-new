import { useState, useEffect } from 'react';
import axios from 'axios';

const useFetch = (url, params = null) => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const source = axios.CancelToken.source();
    
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        setData(null);

        const response = await axios.get(url, {
          params: params,
          cancelToken: source.token
        });
        
        setData(response.data);
      } catch (err) {
        if (axios.isCancel(err)) {
          console.log('Request cancelled',err);
        } else {
          setError(err.message || 'An error occurred');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();

    // Cleanup function to cancel request
    return () => {
      source.cancel('Operation cancelled by the user.');
    };
  }, [url, JSON.stringify(params)]);

  return { data, loading, error };
};

export default useFetch;



