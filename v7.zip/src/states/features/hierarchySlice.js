import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

// Async thunk for fetching hierarchy data
export const fetchHierarchyData = createAsyncThunk(
  'hierarchy/fetchHierarchyData',
  async (formData, { getState, rejectWithValue }) => {
    const { config } = getState().config
    const { apiUrl, username, password } = config
    
    if (!apiUrl || !username || !password) {
      return rejectWithValue("Missing environment variables")
    }
    
    const authConfig = {
      auth: {
        username: username,
        password: password
      }
    }
    
    try {
      const response = await axios.post(
        `${apiUrl}/api/common_master/hierarchy-data`, 
        formData, 
        authConfig
      )
      return {
        data: response?.data?.data || [],
        formData
      }
    } catch (error) {
      return rejectWithValue(error.response?.data?.message || "Failed to fetch hierarchy data")
    }
  }
)

const initialState = {
  companyDetails: [],
  branchDetails: [],
  divDetails: [],
  deptDetails: [],
  loading: false,
  errors: {}
}

const hierarchySlice = createSlice({
  name: 'hierarchy',
  initialState,
  reducers: {
    setCompanyDetails: (state, action) => {
      state.companyDetails = action.payload
    },
    setBranchDetails: (state, action) => {
      state.branchDetails = action.payload
    },
    setDivDetails: (state, action) => {
      state.divDetails = action.payload
    },
    setDeptDetails: (state, action) => {
      state.deptDetails = action.payload
    },
    clearErrors: (state) => {
      state.errors = {}
    },
    setError: (state, action) => {
      state.errors = { ...state.errors, ...action.payload }
    }
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchHierarchyData.pending, (state) => {
        state.loading = true
        state.errors = {}
      })
      .addCase(fetchHierarchyData.fulfilled, (state, action) => {
        state.loading = false
        const { data, formData } = action.payload
        
        if (!formData || Object.keys(formData).length === 0) {
          state.companyDetails = data
          state.divDetails = []
          state.branchDetails = []
          state.deptDetails = []
        } else if (formData.com_sno && !formData.div_sno) {
          state.divDetails = data
          state.branchDetails = []
          state.deptDetails = []
        } else if (formData.com_sno && formData.div_sno && !formData.brn_no) {
          state.branchDetails = data
          state.deptDetails = []
        } else if (formData.com_sno && formData.div_sno && formData.brn_no) {
          state.deptDetails = data
        }
      })
      .addCase(fetchHierarchyData.rejected, (state, action) => {
        state.loading = false
        state.errors.hierarchy = action.payload
        
      })
  }
})
console.log(hierarchySlice.actions)
export const {setCompanyDetails,setBranchDetails,  setDivDetails,  setDeptDetails,clearErrors,setError} = hierarchySlice.actions

// Export selectors
export const selectCompanyDetails = (state) => state.hierarchy.companyDetails
export const selectBranchDetails = (state) => state.hierarchy.branchDetails
export const selectDivDetails = (state) => state.hierarchy.divDetails
export const selectDeptDetails = (state) => state.hierarchy.deptDetails
export const selectHierarchyLoading = (state) => state.hierarchy.loading
export const selectHierarchyErrors = (state) => state.hierarchy.errors

export default hierarchySlice.reducer
